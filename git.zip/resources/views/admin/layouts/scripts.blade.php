    {{-- <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script> --}}
    <script src="{{ asset('admin/dist/js/jquery-3.6.0.min.js') }}"></script>

    <!-- Bundle scripts -->
    <script src="{{ asset('admin/libs/bundle.js') }}"></script>

    <!-- Apex chart -->
    <script src="{{ asset('admin/libs/charts/apex/apexcharts.min.js') }}"></script>

    <!-- Slick -->
    <script src="{{ asset('admin/libs/slick/slick.min.js') }}"></script>

    <!-- Examples -->
    <script src="{{ asset('admin/dist/js/examples/dashboard.js') }}"></script>

    <!-- Main Javascript file -->
    <script src="{{ asset('admin/dist/js/app.min.js') }}"></script>
    <script src="{{asset('admin/plugins/toastr/toastr.min.js')}}"></script>
    <script src="{{asset('admin/dist/js/sweet_alert.js')}}"></script>


    <script src="{{asset('admin/datatables/datatables.net/js/jquery.dataTables.min.js')}}"></script>
    {{-- <script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script> --}}
    <script type="text/javascript" src="{{ asset('admin/dist/js/datatableBootstrap.min.js') }}"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

   