    
    <script src="<?php echo e(asset('admin/dist/js/jquery-3.6.0.min.js')); ?>"></script>

    <!-- Bundle scripts -->
    <script src="<?php echo e(asset('admin/libs/bundle.js')); ?>"></script>

    <!-- Apex chart -->
    <script src="<?php echo e(asset('admin/libs/charts/apex/apexcharts.min.js')); ?>"></script>

    <!-- Slick -->
    <script src="<?php echo e(asset('admin/libs/slick/slick.min.js')); ?>"></script>

    <!-- Examples -->
    <script src="<?php echo e(asset('admin/dist/js/examples/dashboard.js')); ?>"></script>

    <!-- Main Javascript file -->
    <script src="<?php echo e(asset('admin/dist/js/app.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/plugins/toastr/toastr.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/dist/js/sweet_alert.js')); ?>"></script>


    <script src="<?php echo e(asset('admin/datatables/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    
    <script type="text/javascript" src="<?php echo e(asset('admin/dist/js/datatableBootstrap.min.js')); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

   <?php /**PATH D:\Projects\fireStock\resources\views/admin/layouts/scripts.blade.php ENDPATH**/ ?>