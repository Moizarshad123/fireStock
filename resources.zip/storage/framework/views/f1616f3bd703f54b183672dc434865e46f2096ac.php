<!-- menu -->
<div class="menu">
    <div class="menu-header">
        <a href="<?php echo e(route('admin.dashboard')); ?>" class="menu-header-logo">
            
        </a>
        <a href="<?php echo e(url('/')); ?>" class="btn btn-sm menu-close-btn">
            <i class="bi bi-x"></i>
        </a>
    </div>
    <div class="menu-body">
        <div class="dropdown">
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="d-flex align-items-center" data-bs-toggle="dropdown">
                <div class="avatar me-3">
                    <img src="<?php echo e(asset('admin/assets/images/user/man_avatar3.jpg')); ?>"
                         class="rounded-circle" alt="image">
                </div>
                <div>
                    <div class="fw-bold">FireStock</div>
                </div>
            </a>
            
        </div>
        <ul>
            <li>
                <a  class="<?php echo e(request()->IS('admin/dashboard') ? 'active' : ''); ?>"  href="<?php echo e(route('admin.dashboard')); ?>">
                    <span class="nav-link-icon">
                        <i class="bi bi-bar-chart"></i>
                    </span>
                    <span>Dashboard</span>
                </a>
            </li>
          
            <li>
                <a  href="<?php echo e(route('admin.logout')); ?>">
                    <span class="nav-link-icon">
                        <i class="bi bi-person-badge"></i>
                    </span>
                    <span>Logout</span>
                </a>
            </li>
            
           
        </ul>
    </div>
</div>
<!-- ./  menu --><?php /**PATH D:\Projects\fireStock\resources\views/admin/layouts/sidebar.blade.php ENDPATH**/ ?>