
       <!-- header -->
       <div class="header">
        <div class="menu-toggle-btn">
            <!-- Menu close button for mobile devices -->
            <a href="#">
                <i class="bi bi-list"></i>
            </a>
        </div>
        <!-- Logo -->
        <a href="index.html" class="logo">
            <img width="100" src="<?php echo e(asset('admin/assets/images/logo.svg')); ?>" alt="logo">
        </a>
        <!-- ./ Logo -->
        <div class="page-title">Overview</div>
           
            
        <!-- Header mobile buttons -->
        <div class="header-mobile-buttons">
            <a href="#" class="search-bar-btn">
                <i class="bi bi-search"></i>
            </a>
            <a href="#" class="actions-btn">
                <i class="bi bi-three-dots"></i>
            </a>
        </div>
        <!-- ./ Header mobile buttons -->
    </div>
    <!-- ./ header --><?php /**PATH D:\Projects\fireStock\resources\views/admin/layouts/header.blade.php ENDPATH**/ ?>